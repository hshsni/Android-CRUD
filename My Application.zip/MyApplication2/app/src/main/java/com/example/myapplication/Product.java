package com.example.myapplication;

public class Product {
    String id;
    String name;
    String price;
    String stock;
}
