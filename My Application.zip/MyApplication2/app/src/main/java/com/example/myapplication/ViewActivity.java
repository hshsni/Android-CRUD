package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;


public class ViewActivity extends AppCompatActivity {


    ListView lst1;
    ArrayList<String> titles = new ArrayList<String>();
    ArrayAdapter arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        SQLiteDatabase db = openOrCreateDatabase("Retail",Context.MODE_PRIVATE,null);

        lst1 = findViewById(R.id.lst1);
        final Cursor c = db.rawQuery("select * from retail",null);
        int id = c.getColumnIndex("id");
        int name = c.getColumnIndex("name");
        int price = c.getColumnIndex("price");
        int stock = c.getColumnIndex("stock");
        titles.clear();


        arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,titles);
        lst1.setAdapter(arrayAdapter);

        final  ArrayList<Product> stud = new ArrayList<>();


        if(c.moveToFirst())
        {
            do{
                Product stu = new Product();
                stu.id = c.getString(id);
                stu.name = c.getString(name);
                stu.price = c.getString(price);
                stu.stock = c.getString(stock);
                stud.add(stu);

                titles.add(c.getString(id) + " \t " + c.getString(name) + " \t "  + c.getString(price) + " \t "  + c.getString(stock) );

            } while(c.moveToNext());
            arrayAdapter.notifyDataSetChanged();
            lst1.invalidateViews();



        }

        lst1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String aa = titles.get(position).toString();
                Product stu = stud.get(position);
                Intent i = new Intent(getApplicationContext(),EditActivity.class);
                i.putExtra("id",stu.id);
                i.putExtra("name",stu.name);
                i.putExtra("price",stu.price);
                i.putExtra("stock",stu.stock);
                startActivity(i);

            }
        });

    }
}